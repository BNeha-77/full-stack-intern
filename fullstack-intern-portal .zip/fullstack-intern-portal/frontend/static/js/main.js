// main.js - currently empty or used for future frontend JS if needed

console.log('Frontend JS loaded.');

